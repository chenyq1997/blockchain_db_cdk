class handler:
    print("Hello World! \n")
